package com.example.android.dominosscorekeeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int redPlayerScore = 0;
    int bluePlayerScore = 0;
    int greenPlayerScore = 0;
    int blackPlayerScore = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayForBlackPlayer(0);
        displayForBluePlayer(0);
        displayForGreenPlayer(0);
        displayForRedPlayer(0);
    }

    /**
     * Resets all players score to zero this method is called when the reset button is clicked
     */

    public void resetScore (View view) {
        redPlayerScore = 0 ;
        bluePlayerScore = 0;
        greenPlayerScore = 0;
        blackPlayerScore = 0;
        displayForRedPlayer(redPlayerScore);
        displayForBluePlayer(bluePlayerScore);
        displayForGreenPlayer(greenPlayerScore);
        displayForBlackPlayer(blackPlayerScore);


    }



    /**
     * Displays the given score for Red Player.
     */
    public void displayForRedPlayer(int score) {
        TextView scoreView = (TextView) findViewById(R.id.redPlayerScore);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * This method is called when the +5 button for Red Player is clicked
     */
    public void add5ToRedPlayer (View view) {
        redPlayerScore = redPlayerScore +5;
        displayForRedPlayer(redPlayerScore);
    }

    /**
     * This method is called when the +7 button for Red Player is clicked
     */
    public void add7ToRedPlayer (View view) {
        redPlayerScore = redPlayerScore +7;
        displayForRedPlayer(redPlayerScore);
    }

    /**
     * Displays the given score for Blue Player.
     */
    public void displayForBluePlayer(int score) {
        TextView scoreView = (TextView) findViewById(R.id.bluePlayerScore);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * This method is called when the +5 button for Blue Player is clicked
     */
    public void add5ToBluePlayer (View view) {
        bluePlayerScore = bluePlayerScore +5;
        displayForBluePlayer (bluePlayerScore);
    }

    /**
     * This method is called when the +7 button for Blue Player is clicked
     */
    public void add7ToBluePlayer (View view) {
        bluePlayerScore = bluePlayerScore +7;
        displayForBluePlayer (bluePlayerScore);
    }

    /**
     * Displays the given score for Green Player.
     */
    public void displayForGreenPlayer(int score) {
        TextView scoreView = (TextView) findViewById(R.id.greenPlayerScore);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * This method is called when the +5 button for Green Player is clicked
     */
    public void add5ToGreenPlayer (View view) {
        greenPlayerScore = greenPlayerScore +5;
        displayForGreenPlayer (greenPlayerScore);
    }

    /**
     * This method is called when the +7 button for Green Player is clicked
     */
    public void add7ToGreenPlayer (View view) {
        greenPlayerScore = greenPlayerScore +7;
        displayForGreenPlayer (greenPlayerScore);
    }

    /**
     * Displays the given score for Black Player.
     */
    public void displayForBlackPlayer(int score) {
        TextView scoreView = (TextView) findViewById(R.id.blackPlayerScore);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * This method is called when the +5 button for Black Player is clicked
     */
    public void add5ToBlackPlayer (View view) {
        blackPlayerScore = blackPlayerScore +5;
        displayForBlackPlayer(blackPlayerScore);
    }


    /**
     * This method is called when the +7 button for Black Player is clicked
     */
    public void add7ToBlackPlayer (View view) {
        blackPlayerScore = blackPlayerScore +7;
        displayForBlackPlayer(blackPlayerScore);
    }


}

